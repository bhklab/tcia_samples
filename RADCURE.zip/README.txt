The example scans included here come from the LUNG1 dataset and have been reformated to follow RADCURE project structure. This is because RADCURE is still not a public dataset, so we cannot upload the images anywhere.
For full description of the LUNG1 dataset see: https://wiki.cancerimagingarchive.net/display/Public/NSCLC-Radiomics.
